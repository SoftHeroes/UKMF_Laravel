CREATE TABLE `final_e_wallet` (
  `id` int(11) NOT NULL,
  `user_id` varchar(200) NOT NULL,
  `amount` double NOT NULL,
  `status` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `tickets` (
  `id` int(11) NOT NULL,
  `user_id` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `subject` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `tasktype` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `description` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `detail_desc` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `response_email` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `priority` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0',
  `t_date` date NOT NULL,
  `c_t_date` date NOT NULL,
  `response` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `user_name` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `ticket_no` varchar(1000) COLLATE latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

CREATE TABLE `sub_admin_category` (
  `id` int(11) NOT NULL,
  `cat_name` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

CREATE TABLE `sub_admin_sub_category` (
  `id` int(11) NOT NULL,
  `cat_id` varchar(1000) NOT NULL,
  `sub_cat_name` varchar(1000) NOT NULL,
  `link` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

CREATE TABLE `user_registration` (
  `id` int(11) NOT NULL,
  `user_id` varchar(110) NOT NULL,
  `ref_id` varchar(110) NOT NULL,
  `nom_id` varchar(110) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `address` text NOT NULL,
  `city` text NOT NULL,
  `state` text NOT NULL,
  `country` text NOT NULL,
  `zipcode` varchar(100) NOT NULL,
  `telephone` varchar(100) NOT NULL,
  `admin_status` int(11) NOT NULL,
  `user_status` varchar(100) NOT NULL,
  `registration_date` varchar(100) NOT NULL,
  `t_code` varchar(255) NOT NULL,
  `user_plan` varchar(50) NOT NULL,
  `designation` varchar(200) NOT NULL,
  `aboutus` text NOT NULL,
  `dob` varchar(255) NOT NULL,
  `sex` varchar(255) NOT NULL,
  `image` text NOT NULL,
  `acc_name` varchar(100) NOT NULL,
  `ac_no` varchar(50) NOT NULL,
  `bank_nm` varchar(100) NOT NULL,
  `branch_nm` varchar(100) NOT NULL,
  `swift_code` varchar(50) NOT NULL,
  `user_rank_name` varchar(50) NOT NULL,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `merried_status` varchar(100) NOT NULL,
  `last_login_date` varchar(100) NOT NULL,
  `current_login_date` varchar(1000) NOT NULL,
  `binary_pos` varchar(100) NOT NULL,
  `id_card` varchar(100) NOT NULL,
  `id_no` varchar(100) NOT NULL,
  `master_account` varchar(1000) NOT NULL,
  `issued` varchar(100) NOT NULL,
  `product_type` varchar(100) NOT NULL,
  `issue_date` date NOT NULL,
  `admin_remark1` varchar(300) NOT NULL,
  `nom_name` varchar(100) NOT NULL,
  `nom_relation` varchar(100) NOT NULL,
  `nom_mobile` varchar(100) NOT NULL,
  `nom_dob` varchar(100) NOT NULL,
  `bank_state` varchar(100) NOT NULL,
  `ben_fullname` varchar(100) NOT NULL,
  `ben_nric` varchar(100) NOT NULL,
  `device_id` text NOT NULL,
  `device_type` varchar(255) NOT NULL,
  `activation_date` date NOT NULL,
  `actual_rank` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE `visitor` (
  `id` int(11) NOT NULL,
  `user_id` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `username` varchar(1000) COLLATE utf8_unicode_ci NOT NULL,
  `fullname` varchar(1000) COLLATE utf8_unicode_ci NOT NULL,
  `ipadd` varchar(1000) COLLATE utf8_unicode_ci NOT NULL,
  `times` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

CREATE TABLE `withdraw_request` (
  `id` int(11) NOT NULL,
  `transaction_number` varchar(100) NOT NULL,
  `user_id` varchar(111) NOT NULL,
  `first_name` varchar(1000) NOT NULL,
  `last_name` varchar(1000) NOT NULL,
  `acc_name` varchar(1000) NOT NULL,
  `acc_number` varchar(1000) NOT NULL,
  `bank_nm` varchar(1000) NOT NULL,
  `branch_nm` varchar(1000) NOT NULL,
  `swift_code` varchar(1000) NOT NULL,
  `request_amount` varchar(1000) NOT NULL,
  `description` text NOT NULL,
  `status` int(11) NOT NULL,
  `posted_date` varchar(100) NOT NULL,
  `admin_remark` text NOT NULL,
  `admin_response_date` varchar(100) NOT NULL,
  `withdraw_wallet` varchar(1000) NOT NULL,
  `total_paid_amount` varchar(1000) NOT NULL,
  `transaction_charge` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `name` varchar(150) NOT NULL,
  `image` varchar(255) NOT NULL,
  `type` varchar(50) NOT NULL,
  `date` date NOT NULL,
  `add_date_time` datetime NOT NULL,
  `last_modify` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `stutus` int(2) NOT NULL,
  `last_login` datetime NOT NULL,
  `last_logout` datetime NOT NULL,
  `login_status` int(2) NOT NULL,
  `website_logo` varchar(10000) NOT NULL,
  `transaction_pwd` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `admin_privileges` (
  `privilege_id` int(11) NOT NULL,
  `privilege_page` varchar(100) NOT NULL,
  `date` date NOT NULL,
  `add_date_time` datetime NOT NULL,
  `last_modify` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` int(2) NOT NULL,
  `admin_id` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `contactdetail` (
  `id` int(11) NOT NULL,
  `page_name` varchar(2000) NOT NULL,
  `description` text NOT NULL,
  `posted_date` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `country` (
  `id` int(11) NOT NULL,
  `iso` char(2) NOT NULL,
  `name` varchar(80) NOT NULL,
  `nicename` varchar(80) NOT NULL,
  `iso3` char(3) DEFAULT NULL,
  `numcode` smallint(6) DEFAULT NULL,
  `phonecode` int(5) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

CREATE TABLE `credit_debit` (
  `id` int(11) NOT NULL,
  `transaction_no` varchar(1000) COLLATE utf8_unicode_ci NOT NULL,
  `user_id` varchar(1000) COLLATE utf8_unicode_ci NOT NULL,
  `credit_amt` varchar(1000) COLLATE utf8_unicode_ci NOT NULL,
  `debit_amt` varchar(1000) COLLATE utf8_unicode_ci NOT NULL,
  `admin_charge` varchar(1000) COLLATE utf8_unicode_ci NOT NULL,
  `receiver_id` varchar(1000) COLLATE utf8_unicode_ci NOT NULL,
  `sender_id` varchar(1000) COLLATE utf8_unicode_ci NOT NULL,
  `receive_date` varchar(1000) COLLATE utf8_unicode_ci NOT NULL,
  `ttype` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `TranDescription` varchar(1000) COLLATE utf8_unicode_ci NOT NULL,
  `Cause` varchar(1000) COLLATE utf8_unicode_ci NOT NULL,
  `Remark` varchar(1000) COLLATE utf8_unicode_ci NOT NULL,
  `invoice_no` varchar(1000) COLLATE utf8_unicode_ci NOT NULL,
  `product_name` varchar(1000) COLLATE utf8_unicode_ci NOT NULL,
  `status` varchar(1000) COLLATE utf8_unicode_ci NOT NULL,
  `ewallet_used_by` varchar(1000) COLLATE utf8_unicode_ci NOT NULL,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `current_url` varchar(1000) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

CREATE TABLE `credit_debit-old13feb2019` (
  `id` int(11) NOT NULL,
  `transaction_no` varchar(1000) COLLATE utf8_unicode_ci NOT NULL,
  `user_id` varchar(1000) COLLATE utf8_unicode_ci NOT NULL,
  `credit_amt` varchar(1000) COLLATE utf8_unicode_ci NOT NULL,
  `debit_amt` varchar(1000) COLLATE utf8_unicode_ci NOT NULL,
  `admin_charge` varchar(1000) COLLATE utf8_unicode_ci NOT NULL,
  `receiver_id` varchar(1000) COLLATE utf8_unicode_ci NOT NULL,
  `sender_id` varchar(1000) COLLATE utf8_unicode_ci NOT NULL,
  `receive_date` varchar(1000) COLLATE utf8_unicode_ci NOT NULL,
  `ttype` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `TranDescription` varchar(1000) COLLATE utf8_unicode_ci NOT NULL,
  `Cause` varchar(1000) COLLATE utf8_unicode_ci NOT NULL,
  `Remark` varchar(1000) COLLATE utf8_unicode_ci NOT NULL,
  `invoice_no` varchar(1000) COLLATE utf8_unicode_ci NOT NULL,
  `product_name` varchar(1000) COLLATE utf8_unicode_ci NOT NULL,
  `status` varchar(1000) COLLATE utf8_unicode_ci NOT NULL,
  `ewallet_used_by` varchar(1000) COLLATE utf8_unicode_ci NOT NULL,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `current_url` varchar(1000) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

CREATE TABLE `credit_debit-old16jan2018` (
  `id` int(11) NOT NULL,
  `transaction_no` varchar(1000) COLLATE utf8_unicode_ci NOT NULL,
  `user_id` varchar(1000) COLLATE utf8_unicode_ci NOT NULL,
  `credit_amt` varchar(1000) COLLATE utf8_unicode_ci NOT NULL,
  `debit_amt` varchar(1000) COLLATE utf8_unicode_ci NOT NULL,
  `admin_charge` varchar(1000) COLLATE utf8_unicode_ci NOT NULL,
  `receiver_id` varchar(1000) COLLATE utf8_unicode_ci NOT NULL,
  `sender_id` varchar(1000) COLLATE utf8_unicode_ci NOT NULL,
  `receive_date` varchar(1000) COLLATE utf8_unicode_ci NOT NULL,
  `ttype` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `TranDescription` varchar(1000) COLLATE utf8_unicode_ci NOT NULL,
  `Cause` varchar(1000) COLLATE utf8_unicode_ci NOT NULL,
  `Remark` varchar(1000) COLLATE utf8_unicode_ci NOT NULL,
  `invoice_no` varchar(1000) COLLATE utf8_unicode_ci NOT NULL,
  `product_name` varchar(1000) COLLATE utf8_unicode_ci NOT NULL,
  `status` varchar(1000) COLLATE utf8_unicode_ci NOT NULL,
  `ewallet_used_by` varchar(1000) COLLATE utf8_unicode_ci NOT NULL,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `current_url` varchar(1000) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


CREATE TABLE `matrix_downline` (
  `id` int(11) NOT NULL,
  `down_id` varchar(222) NOT NULL,
  `income_id` varchar(222) NOT NULL,
  `level` varchar(222) NOT NULL,
  `l_date` date NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

CREATE TABLE `matrix_downline_ref` (
  `id` int(11) NOT NULL,
  `down_id` varchar(222) NOT NULL,
  `income_id` varchar(222) NOT NULL,
  `level` varchar(222) NOT NULL,
  `l_date` date NOT NULL,
  `status` int(11) NOT NULL,
  `com_status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

CREATE TABLE `paymentproof` (
  `id` int(11) NOT NULL,
  `user` varchar(100) NOT NULL,
  `bank` varchar(100) NOT NULL,
  `amount` varchar(100) NOT NULL,
  `tranno` varchar(100) NOT NULL,
  `paymentproof` varchar(100) NOT NULL,
  `posteddate` date NOT NULL,
  `status` varchar(10) NOT NULL,
  `buy_rate_user` varchar(255) NOT NULL,
  `payment_mode` varchar(255) NOT NULL,
  `buy_rate_admin` varchar(255) NOT NULL,
  `admin_approval_date` date NOT NULL,
  `lifejacketid` varchar(100) NOT NULL,
  `final_point_alloted_on_approval` varchar(100) NOT NULL,
  `fourfive_days_matured` varchar(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

CREATE TABLE `pins` (
  `id` int(11) NOT NULL,
  `pin_no` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `amount` double NOT NULL,
  `status` tinyint(1) NOT NULL,
  `crt_date` date NOT NULL,
  `created_by_user` varchar(200) COLLATE latin1_general_ci NOT NULL,
  `receiver_id` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `sender_id` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `t_date` date NOT NULL,
  `used_by` varchar(20) COLLATE latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;


CREATE TABLE `points_e_wallet` (
  `id` int(11) NOT NULL,
  `user_id` varchar(200) NOT NULL,
  `amount` double NOT NULL,
  `status` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `popup` (
  `id` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

CREATE TABLE `promo` (
  `news_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `n_id` int(100) NOT NULL,
  `description` longtext COLLATE utf8_unicode_ci NOT NULL,
  `n_date` date NOT NULL,
  `status` int(3) NOT NULL DEFAULT '1',
  `read_viewer` int(2) NOT NULL DEFAULT '1',
  `posted_date` varchar(1000) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

CREATE TABLE `rank_achiever` (
  `id` int(11) NOT NULL,
  `user_id` varchar(100) NOT NULL,
  `from_rank` varchar(100) NOT NULL,
  `to_rank` varchar(100) NOT NULL,
  `posted_date` date NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;