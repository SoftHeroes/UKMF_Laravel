/// Convenience class for giving names to key identifiers.
class KeyCode {
  static const int escape = 0x100070029;
  static const int backspace = 0x10007002a;
}
